import { getFirestore, collection, doc, setDoc } from 'firebase/firestore';
import { initializeApp } from 'firebase/app';

const firebaseConfig = {
    apiKey: 'AIzaSyCbj5GPq-JQ12AJSeB8WBkTavwv8-xz4WU',
    authDomain: 'devdeakinlogin.firebaseapp.com',
    projectId: 'devdeakinlogin',
    storageBucket: 'devdeakinlogin.appspot.com',
    messagingSenderId: '131973953980',
    appId: '1:131973953980:web:c7ae3337e48148156693b9',
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const addProductToFirestore = async () => {
  const productRef = doc(collection(db, 'products'), 'productId'); // Replace 'productId' with your product ID
  await setDoc(productRef, {
    name: 'Basic Plan',
    description: 'This is the basic plan.',
    active: true,
  });

  const priceRef = doc(collection(productRef, 'prices'), 'price_1Q3yiWCkr1BtDqejrjKnmxii'); // Replace 'priceId' with your price ID
  await setDoc(priceRef, {
    unit_amount: 1000,
    currency: 'usd',
    active: true,
  });

  console.log('Product and price added to Firestore');
};

addProductToFirestore().catch(console.error);